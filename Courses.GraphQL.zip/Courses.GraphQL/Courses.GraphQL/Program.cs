using Courses.GraphQL.Data;
using Courses.GraphQL.Data.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Courses.GraphQL
{
    public class Program
    {
        public static void Main(string[] args)
        {


            AppDbContext AppDbContext = new AppDbContext();
            if (AppDbContext.Courses != null)
            {
                AppDbContext.Courses.RemoveRange(AppDbContext.Courses);
                AppDbContext.SaveChanges();
            }

            Course c1 = new Course("a", "des1", 1);
            Course c2 = new Course("b", "des2", 2);
            Course c3 = new Course("c", "des3", 3);
            Course c4 = new Course("d", "des4", 4);

            AppDbContext.Add(c1); AppDbContext.Add(c2);
            AppDbContext.Add(c3);  AppDbContext.Add(c4);
            AppDbContext.SaveChanges(); 



            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });
    }
}
